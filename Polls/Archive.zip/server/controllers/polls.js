var mongoose = require('mongoose');
var Polls = mongoose.model('Polls');
var User = mongoose.model('User');

module.exports = (function() {
	return {
		create: function(req, res) {
			var newPoll = new Polls(req.body);
			newPoll.save(function(err, data) {
				if(err)
					console.log(err)
				else
					User.findOneAndUpdate({_id: data.user_id}, {poll_id: data._id}, {upsert: true}, function(err, update){
						res.json(update);	
					})
			})
		},

		read: function(req, res) {
			Polls.find({}, function(err, data) {
				if(err)
					console.log(err)
				else
					res.json(data)
			})
		},
		readOne: function(req, res) {
			console.log(req.params);
			Polls.find({_id: req.params.id}, function(err, data) {
				if(err)
					console.log(err)
				else
					res.json(data)
			})
		},
		remove: function(req, res){
			console.log("This is req.body: ",req.body);
			console.log(req.params);
			Polls.findOne({user_id: req.body.user_id}, function(err, user){
				if(err)
					console.log(err)
				else
					res.json(user);
			})
		},
		addVote: function(req, res){
			console.log(req.body);
		},
		votes: function(req, res){
			console.log(req.body);
			console.log(req.params);
		}
	}
})();